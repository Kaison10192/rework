// src/app/catalog/page.tsx
"use client";

import TopPopular from "@/components/home/TopPopular";

import CatalogWithLanterns from "@/components/home/CatalogWithLanterns";

export default function CatalogPage() {
  return (
    <main className="relative min-h-screen bg-background text-text pt-16">
      <TopPopular />
    
      <CatalogWithLanterns />
    </main>
  );
}
