"use client";

import Image from "next/image";
import { motion, useMotionValue, useAnimationFrame } from "framer-motion";

/* ===============================================================
   🔆 NEON CONFIG
================================================================ */
const NEON = {
  colorRGB: "255,255,255",
  rim: 4,
  strong: 1,
  soft: 1,
};

function neonFilter(
  colorRGB: string = NEON.colorRGB,
  rim: number = NEON.rim,
  strong: number = NEON.strong,
  soft: number = NEON.soft
) {
  return `
    drop-shadow(0 0 ${Math.max(1, rim)}px rgb(${colorRGB}))
    drop-shadow(0 0 ${Math.max(1, strong)}px rgb(${colorRGB}))
    drop-shadow(0 0 ${Math.max(1, soft)}px rgba(${colorRGB},.45))
  `;
}

/* ===============================================================
   🌀 RING IMAGE
================================================================ */
function RingImage({
  size = 320,
  rotate = 0,
  opacity = 1,
  glow = 0,
  glowColor = "#ffffff",
  glowStrong = 0,
  offsetX = 0,
  offsetY = 0,
  className = "",
}: {
  size?: number;
  rotate?: number;
  opacity?: number;
  glow?: number;
  glowColor?: string;
  glowStrong?: number;
  offsetX?: number;
  offsetY?: number;
  className?: string;
}) {
  const filterStr =
    glow > 0 || glowStrong > 0
      ? `drop-shadow(0 0 ${glow}px ${glowColor}) drop-shadow(0 0 ${glowStrong}px ${glowColor})`
      : neonFilter();

  return (
    <div
      className={`absolute pointer-events-none ${className}`}
      style={{
        left: "50%",
        top: "50%",
        width: size,
        height: size,
        transform: `translate(-50%,-50%) translate(${offsetX}px,${offsetY}px) rotate(${rotate}deg)`,
        opacity,
      }}
      aria-hidden
    >
      <Image
        src="/วงแหวน.png"
        alt="ring"
        fill
        sizes={`${size}px`}
        className="object-contain select-none pointer-events-none"
        priority
        style={{ filter: filterStr, mixBlendMode: "screen" }}
      />
    </div>
  );
}

/* ===============================================================
   🏮 CENTER LANTERNS
================================================================ */

export type Tab = "comic" | "novel";
type Vec2 = { x: number; y: number };

type PagerProps = {
  page: number;
  totalPages: number;
  onPrev: () => void;
  onNext: () => void;
  arrowOffset?: number;

  arrowSize?: number;
  arrowScaleLeft?: number;
  arrowScaleRight?: number;
  arrowShiftLeft?: Vec2;
  arrowShiftRight?: Vec2;

  ringSize: number;
  ringOffsetX: number;
  ringOffsetY: number;
};

const LABEL_COLOR = "#EEE9DD";
const LABEL_COLOR_ACTIVE = "#FFFFFF";

function LabelWord({
  src,
  width,
  height,
  active,
}: {
  src: string;
  width: number;
  height: number;
  active: boolean;
}) {
  return (
    <span
      aria-hidden
      style={{
        display: "block",
        width,
        height,
        backgroundColor: active ? LABEL_COLOR_ACTIVE : LABEL_COLOR,
        WebkitMaskImage: `url(${src})`,
        maskImage: `url(${src})`,
        WebkitMaskSize: "contain",
        maskSize: "contain",
        WebkitMaskRepeat: "no-repeat",
        maskRepeat: "no-repeat",
        WebkitMaskPosition: "center",
        maskPosition: "center",
        transition: "background-color 200ms ease, filter 200ms ease",
        filter: active ? "brightness(1.04)" : "none",
      }}
    />
  );
}

type Anchor = "center" | "top-left" | "top-right" | "bottom-left" | "bottom-right";

export default function CenterLanterns({
  /* ——— แท็บ ——— */
  tab,
  onSelect,

  /* ——— วงแหวน ——— */
  ringSize = 320,
  ringRotate = 0,
  ringOpacity = 1,
  ringGlow = 0,
  ringOffsetX = 0,
  ringOffsetY = 0,

  /* ——— Pager ——— */
  page,
  totalPages,
  onPrev,
  onNext,

  /* ——— ลูกศร ——— */
  arrowSize = 230,
  arrowScaleLeft = 1,
  arrowScaleRight = 1,
  arrowShiftLeft = { x: 0, y: -55 },
  arrowShiftRight = { x: 0, y: -55 },
  arrowOffset = 28,

  /* ——— เลขหน้าข้างลูกศร ——— */
  onJump,
  showSidePages = false,      // ให้พาเรนต์เปิด/ปิด (เริ่มโชว์ตั้งแต่หน้า 2)
  sideCount = 2,              // จำนวนเลขต่อข้าง
  sideStep = 140,             // ระยะห่างเลขต่อกัน (px)
  sideY = -6,                 // ตำแหน่งแนวตั้งของเลข

  /* ——— วางตำแหน่งชุดตะเกียง ——— */
  anchor = "center",
  x = 50,
  y = 50,
  unit = "%",
  scale = 1,
  z = 10,
  pointer = "auto",
  containerClassName = "",
}: {
  tab: Tab;
  onSelect: (t: Tab) => void;

  ringSize?: number;
  ringRotate?: number;
  ringOpacity?: number;
  ringGlow?: number;
  ringOffsetX?: number;
  ringOffsetY?: number;

  page: number;
  totalPages: number;
  onPrev: () => void;
  onNext: () => void;

  arrowSize?: number;
  arrowScaleLeft?: number;
  arrowScaleRight?: number;
  arrowShiftLeft?: Vec2;
  arrowShiftRight?: Vec2;
  arrowOffset?: number;

  /** เลขกระโดดหน้าข้างลูกศร */
  onJump?: (p: number) => void;
  showSidePages?: boolean;
  sideCount?: number;
  sideStep?: number;
  sideY?: number;

  anchor?: Anchor;
  x?: number;
  y?: number;
  unit?: "%" | "px";
  scale?: number;
  z?: number;
  pointer?: "auto" | "none";
  containerClassName?: string;
}) {
  const LANTERN_W = 300;
  const LANTERN_H = Math.round(LANTERN_W * 1.4);

  /* 🧭 helper: คำนวณ anchor translate */
  function anchorTranslate(a: Anchor) {
    switch (a) {
      case "center":
        return "translate(-50%, -50%)";
      case "top-left":
        return "translate(0, 0)";
      case "top-right":
        return "translate(-100%, 0)";
      case "bottom-left":
        return "translate(0, -100%)";
      case "bottom-right":
        return "translate(-100%, -100%)";
    }
  }

  /* 🏮 ปุ่มตะเกียง (ตัด resetToFirst ออก) */
  function LanternBtn({
    t,
    rotateDeg,
    dx,
    dy,
    glowX,
    glowY,
    labelOffsetX,
    labelOffsetY,
    labelScale,
  }: {
    t: Tab;
    rotateDeg: number;
    dx: number;
    dy: number;
    glowX: number;
    glowY: number;
    labelOffsetX: number;
    labelOffsetY: number;
    labelScale: number;
  }) {
    const active = tab === t;
    const glowOpacity = useMotionValue(1);
    const groupY = useMotionValue(0);

    useAnimationFrame((tms: number) => {
      const tsec = tms / 1000;
      groupY.set(Math.sin(tsec * 0.8) * 4);
      const base = 0.85 + Math.sin(tsec * 2.2) * 0.08;
      const micro = 0.04 * (Math.sin(tsec * 17.0) * Math.sin(tsec * 13.1));
      glowOpacity.set(active ? base + micro : 0.55);
    });

    return (
      <div
        className="absolute"
        style={{
          left: "50%",
          top: "50%",
          transform: `translate(-50%, -50%) translate(${dx}px, ${dy}px)`,
        }}
      >
        <motion.button
          type="button"
          onClick={() => onSelect(t)}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.98 }}
          className="relative block"
          aria-label={t === "comic" ? "การ์ตูน" : "นิยาย"}
          style={{
            filter: active ? "brightness(1.3)" : "brightness(0.5) grayscale(0.15)",
          }}
        >
          <motion.div
            style={{ y: groupY, rotate: rotateDeg, transformOrigin: "50% 40%" }}
            className="relative"
          >
            {/* glow ภายในโคมไฟ */}
            <motion.div
              className="absolute pointer-events-none"
              style={{
                width: LANTERN_W * 1.2,
                height: LANTERN_W * 1.2,
                top: glowY - (LANTERN_W * 1.1) / 2,
                left: glowX - (LANTERN_W * 1.1) / 2,
                opacity: glowOpacity,
                filter: "blur(50px)",
                background:
                  "radial-gradient(circle, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0.22) 28%, rgba(255,170,0,0.12) 45%, rgba(196,29,29,0) 70%)",
              }}
            />
            <Image
              src="/lantern2.png"
              alt={t === "comic" ? "การ์ตูน" : "นิยาย"}
              width={LANTERN_W}
              height={LANTERN_H}
              className="object-contain pointer-events-none select-none drop-shadow-[0_10px_30px_rgba(0,0,0,.5)]"
              draggable={false}
              priority
            />
          </motion.div>

          {/* ป้ายคำ */}
          <div
            className="absolute z-10"
            style={{
              left: `calc(50% + ${labelOffsetX}px)`,
              top: `calc(50% + ${labelOffsetY}px)`,
              transform: `translate(-50%, -50%) scale(${labelScale})`,
            }}
          >
            <LabelWord
              src={t === "comic" ? "/การ์ตูน.png" : "/นิยาย.png"}
              width={180}
              height={70}
              active={active}
            />
          </div>
        </motion.button>
      </div>
    );
  }

  /* 🎯 ปุ่มลูกศร + เลขหน้า (รวมเลขข้าง) */
  function CenterPager({
    page,
    totalPages,
    onPrev,
    onNext,
    arrowOffset = 28,
    arrowSize = 220,
    arrowScaleLeft = 1,
    arrowScaleRight = 1,
    arrowShiftLeft = { x: 0, y: 0 },
    arrowShiftRight = { x: 0, y: 0 },
    ringSize,
    ringOffsetX,
    ringOffsetY,
  }: PagerProps) {
    function ArrowImgBtn({
      dir = "left",
      sizeBase = 220,
      onClick,
    }: {
      dir?: "left" | "right";
      sizeBase?: number;
      onClick: () => void;
    }) {
      const glow = neonFilter();
      return (
        <motion.button
          type="button"
          onClick={onClick}
          whileHover={{ scale: 1.06 }}
          whileTap={{ scale: 0.96 }}
          aria-label={dir === "left" ? "ก่อนหน้า" : "ถัดไป"}
          style={{ display: "block", position: "relative", zIndex: 50 }}
        >
          <div
            style={{
              position: "relative",
              width: sizeBase,
              height: sizeBase,
              transform: dir === "left" ? "scaleX(-1)" : "none",
            }}
          >
            <Image
              src="/arrow.png"
              alt=""
              width={sizeBase}
              height={sizeBase}
              unoptimized
              draggable={false}
              style={{
                position: "absolute",
                inset: 0,
                filter: glow,
                mixBlendMode: "screen",
                opacity: 0.95,
                pointerEvents: "none",
              }}
            />
            <Image
              src="/arrow.png"
              alt={dir === "left" ? "ก่อนหน้า" : "ถัดไป"}
              width={sizeBase}
              height={sizeBase}
              unoptimized
              draggable={false}
              style={{ position: "relative", display: "block", pointerEvents: "none" }}
            />
          </div>
        </motion.button>
      );
    }

    const clamped = Math.max(1, Math.min(totalPages, page)); // กันค่าหลุดกรอบ

    const numberStyleCenter: React.CSSProperties = {
      fontSize: 76,
      color: "#000",
      WebkitTextStroke: "2.5px #fff",
      textShadow: "0 0 10px rgba(255,255,255,.25), 0 0 3px rgba(255,255,255,.25)",
      letterSpacing: 2,
    };

    const numberStyleSide: React.CSSProperties = {
      fontSize: 58,
      color: "#000",
      WebkitTextStroke: "2px #fff",
      textShadow: "0 0 8px rgba(255,255,255,.25), 0 0 3px rgba(255,255,255,.2)",
      letterSpacing: 1,
    };

    /* จัดทำรายการเลขซ้าย/ขวา (เริ่มแสดงตั้งแต่หน้า 2) */
    const shouldShowSides = showSidePages && clamped > 1;

    const leftPages = shouldShowSides
      ? Array.from({ length: sideCount })
          .map((_, i) => clamped - (sideCount - i))
          .filter((p) => p >= 1)
      : [];

    const rightPages = shouldShowSides
      ? Array.from({ length: sideCount })
          .map((_, i) => clamped + (i + 1))
          .filter((p) => p <= totalPages)
      : [];

    /* คำนวณตำแหน่งเลขให้ “เลยปลายลูกศรออกไป” */
    const baseLeft =
      -(ringSize / 2 + arrowOffset) + arrowShiftLeft.x - arrowSize * 0.55; // เลยปลายลูกศรซ้าย
    const baseRight =
      +(ringSize / 2 + arrowOffset) + arrowShiftRight.x + arrowSize * 0.55; // เลยปลายลูกศรขวา

    const makeSideX = (base: number, index: number, dir: "L" | "R") =>
      dir === "L" ? base - (index + 1) * sideStep : base + (index + 1) * sideStep;

    const SideNumber = ({ p, x }: { p: number; x: number }) => (
      <button
        type="button"
        onClick={() => onJump?.(p)}
        className="absolute z-30 select-none"
        style={{
          left: "50%",
          top: "50%",
          transform: `translate(-50%, -50%) translate(${x}px, ${sideY}px)`,
        }}
        title={`ไปหน้า ${p}`}
      >
        <span style={numberStyleSide}>{p}</span>
      </button>
    );

    return (
      <>
        {/* เลขตรงกลางวง */}
        <div
          className="absolute z-20 select-none"
          style={{
            left: "50%",
            top: "50%",
            transform: `translate(-50%, -50%) translate(${ringOffsetX}px, ${ringOffsetY}px)`,
          }}
        >
          <span style={numberStyleCenter}>{clamped}</span>
        </div>

        {/* ลูกศร */}
        <div
          className="absolute z-20"
          style={{
            left: "50%",
            top: "50%",
            transform: `
              translate(-50%, -50%)
              translate(${ringOffsetX - ringSize / 2 - arrowOffset + arrowShiftLeft.x}px,
                        ${ringOffsetY + arrowShiftLeft.y}px)
              scale(${arrowScaleLeft})
            `,
            transformOrigin: "50% 50%",
          }}
        >
          <ArrowImgBtn dir="left" sizeBase={arrowSize} onClick={onPrev} />
        </div>

        <div
          className="absolute z-20"
          style={{
            left: "50%",
            top: "50%",
            transform: `
              translate(-50%, -50%)
              translate(${ringOffsetX + ringSize / 2 + arrowOffset + arrowShiftRight.x}px,
                        ${ringOffsetY + arrowShiftRight.y}px)
              scale(${arrowScaleRight})
            `,
            transformOrigin: "50% 50%",
          }}
        >
          <ArrowImgBtn dir="right" sizeBase={arrowSize} onClick={onNext} />
        </div>

        {/* เลขหน้าข้างลูกศร (เริ่มตั้งแต่หน้า 2) */}
        {shouldShowSides && (
          <>
            {/* ⬅️ ฝั่งซ้าย: กลับ index เพื่อให้เลขที่ “น้อยกว่า” ไปอยู่ซ้ายสุด */}
            {leftPages.map((p, idx) => (
              <SideNumber
                key={`SL-${p}`}
                p={p}
                x={makeSideX(baseLeft, leftPages.length - 1 - idx, "L")}
              />
            ))}

            {/* ➡️ ฝั่งขวา: คงเดิม */}
            {rightPages.map((p, idx) => (
              <SideNumber key={`SR-${p}`} p={p} x={makeSideX(baseRight, idx, "R")} />
            ))}
          </>
        )}
      </>
    );
  }

  /* ---------------- Layout ---------------- */
  return (
    <div
      className={containerClassName}
      style={{
        position: "absolute",
        left: unit === "%" ? `${x}%` : x,
        top: unit === "%" ? `${y}%` : y,
        transform: `${anchorTranslate(anchor)} scale(${scale})`,
        transformOrigin: "center",
        zIndex: z,
        pointerEvents: pointer,
      }}
    >
      <div className="relative w-[1200px] h-[800px]">
        <RingImage
          size={ringSize}
          rotate={ringRotate}
          opacity={ringOpacity}
          offsetX={ringOffsetX}
          offsetY={ringOffsetY}
        />

        <CenterPager
          page={page}
          totalPages={totalPages}
          onPrev={onPrev}
          onNext={onNext}
          arrowOffset={arrowOffset}
          arrowSize={arrowSize}
          arrowScaleLeft={arrowScaleLeft}
          arrowScaleRight={arrowScaleRight}
          arrowShiftLeft={arrowShiftLeft}
          arrowShiftRight={arrowShiftRight}
          ringSize={ringSize}
          ringOffsetX={ringOffsetX}
          ringOffsetY={ringOffsetY}
        />

        {/* ปุ่มเลือกแท็บ */}
        <LanternBtn
          t="comic"
          rotateDeg={-22}
          dx={-190}
          dy={-60}
          glowX={LANTERN_W * 0.6}
          glowY={LANTERN_H * 0.5}
          labelOffsetX={185}
          labelOffsetY={-120}
          labelScale={2.3}
        />
        <LanternBtn
          t="novel"
          rotateDeg={18}
          dx={130}
          dy={50}
          glowX={LANTERN_W * 0.6}
          glowY={LANTERN_H * 0.5}
          labelOffsetX={-130}
          labelOffsetY={140}
          labelScale={2.0}
        />
      </div>
    </div>
  );
}
