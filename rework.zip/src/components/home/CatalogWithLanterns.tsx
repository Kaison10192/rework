// src/components/home/CatalogWithLanterns.tsx
"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import CenterLanterns, { Tab } from "@/components/home/CenterLanterns";
import { usePathname, useRouter, useSearchParams } from "next/navigation";

/* ---------- utils ---------- */
function mulberry32(a: number) {
  return function () {
    let t = (a += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function hashString(s: string) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

type Item = {
  id: string | number;
  title: string;
  author: string;
  cover_url: string;
  rating: number;
  country: string;
  views: string;
  chapters: number;
  updated: string;
};

const PER_PAGE = 24; // ✅ แถวละ 2 การ์ด
const TOTAL_PAGES = 120;
const WARP_OFFSET = 340;

/* ---------- mock data ---------- */
function makeMock(tab: Tab, page: number, perPage: number): Item[] {
  return Array.from({ length: perPage }).map((_, i) => {
    const n = (page - 1) * perPage + i + 1;
    const seed = hashString(`${tab}-${page}-${n}`);
    const rnd = mulberry32(seed);
    return {
      id: `${tab}-${n}`,
      title: tab === "comic" ? `การ์ตูนตัวอย่าง #${n}` : `นิยายตัวอย่าง #${n}`,
      author: tab === "comic" ? "สตูดิโอ X" : "นักเขียน Y",
      cover_url: `https://picsum.photos/seed/${tab}-${n}/600/800`,
      rating: Math.round((rnd() * 2 + 3) * 10) / 10,
      country: "KR",
      views: `${(rnd() * 8 + 0.7).toFixed(1)}k`,
      chapters: Math.floor(rnd() * 80) + 10,
      updated: `${Math.floor(rnd() * 24)} ชั่วโมงที่แล้ว`,
    };
  });
}

/* ---------- หา scroll container ---------- */
function getScrollParent(node: HTMLElement | null): HTMLElement | Window {
  if (!node) return window;
  let el: HTMLElement | null = node;
  while (el && el.parentElement) {
    const style = getComputedStyle(el);
    const oy = style.overflowY;
    if (/(auto|scroll|overlay)/.test(oy) && el.scrollHeight > el.clientHeight) {
      return el;
    }
    el = el.parentElement;
  }
  const se = document.scrollingElement as HTMLElement | null;
  return se ?? window;
}

/* =========================
   Main Component
========================= */
export default function CatalogWithLanterns() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [tab, setTab] = useState<Tab>(() => {
    const tFromUrl = (searchParams?.get("tab") || "").toLowerCase();
    if (tFromUrl === "comic" || tFromUrl === "novel") return tFromUrl as Tab;
    if (typeof window !== "undefined") {
      const t = localStorage.getItem("takiang_tab");
      if (t === "comic" || t === "novel") return t as Tab;
    }
    return "comic";
  });

  const [page, setPage] = useState<number>(() => {
    const pFromUrl = Number(searchParams?.get("page") || NaN);
    if (Number.isFinite(pFromUrl)) {
      const clamped = Math.max(1, Math.min(TOTAL_PAGES, Math.floor(pFromUrl)));
      if (clamped) return clamped;
    }
    if (typeof window !== "undefined") {
      const pStr = localStorage.getItem("takiang_page");
      const p = pStr ? Number(pStr) : NaN;
      if (Number.isFinite(p)) {
        const clamped = Math.max(1, Math.min(TOTAL_PAGES, Math.floor(p)));
        if (clamped) return clamped;
      }
    }
    return 1;
  });

  const gridRef = useRef<HTMLDivElement>(null);
  const warpNext = useRef(false);

  function warpToTop(_label = "effect", retry = 0) {
    const anchor = gridRef.current;
    if (!anchor) return;

    const scroller = getScrollParent(anchor);
    const scrollerRect =
      scroller instanceof Window
        ? { top: 0 }
        : (scroller as HTMLElement).getBoundingClientRect();

    const anchorRect = anchor.getBoundingClientRect();
    const distanceFromScrollerTop =
      anchorRect.top - (scroller instanceof Window ? 0 : scrollerRect.top);
    const currentScrollTop =
      scroller instanceof Window
        ? window.scrollY
        : (scroller as HTMLElement).scrollTop;
    const target = currentScrollTop + distanceFromScrollerTop - WARP_OFFSET;

    if (Math.abs(distanceFromScrollerTop) < 10 && retry < 8) {
      setTimeout(() => warpToTop("effect", retry + 1), 80);
      return;
    }

    if (scroller instanceof Window) {
      window.scrollTo({ top: Math.max(0, target), behavior: "smooth" });
    } else {
      (scroller as HTMLElement).scrollTo({
        top: Math.max(0, target),
        behavior: "smooth",
      });
    }
  }

  const forceWarpSoon = () => {
    requestAnimationFrame(() => setTimeout(() => warpToTop("force"), 60));
  };

  useEffect(() => {
    if (warpNext.current) {
      warpNext.current = false;
      requestAnimationFrame(() => setTimeout(() => warpToTop("effect"), 60));
    }
  }, [page]);

  useEffect(() => {
    const sp = new URLSearchParams(searchParams?.toString());
    let changed = false;
    if (sp.get("tab") !== tab) {
      sp.set("tab", tab);
      changed = true;
    }
    if (sp.get("page") !== String(page)) {
      sp.set("page", String(page));
      changed = true;
    }
    if (changed) {
      router.replace(`${pathname}?${sp.toString()}`, { scroll: false });
    }
    try {
      localStorage.setItem("takiang_tab", tab);
      localStorage.setItem("takiang_page", String(page));
    } catch {}
  }, [tab, page, router, pathname]);

  const items = useMemo(() => makeMock(tab, page, PER_PAGE), [tab, page]);

  const goPrevBottom = () => {
    if (page > 1) {
      warpNext.current = true;
      setPage((p) => p - 1);
      forceWarpSoon();
    }
  };
  const goNextBottom = () => {
    if (page < TOTAL_PAGES) {
      warpNext.current = true;
      setPage((p) => p + 1);
      forceWarpSoon();
    }
  };
  const jumpBottom = (p: number) => {
    warpNext.current = true;
    setPage(p);
    forceWarpSoon();
  };

  return (
    <section className="relative w-full">
      {/* ===== ตะเกียงบน ===== */}
      <div className="relative mx-auto max-w-[1320px] h-[520px] overflow-visible">
        <CenterLanterns
          tab={tab}
          onSelect={(t) => {
            setTab(t);
            warpNext.current = true;
            setPage(1);
            forceWarpSoon();
          }}
          page={page}
          totalPages={TOTAL_PAGES}
          onPrev={() => setPage((p) => Math.max(1, p - 1))}
          onNext={() => setPage((p) => Math.min(TOTAL_PAGES, p + 1))}
          onJump={(p) => setPage(p)}
          showSidePages
          sideCount={2}
          anchor="center"
          x={50}
          y={60}
          unit="%"
          scale={0.76}
          z={10}
          pointer="auto"
          containerClassName="mx-auto"
          ringSize={420}
          ringRotate={0}
          ringOpacity={1}
          ringGlow={0}
          ringOffsetX={0}
          ringOffsetY={0}
          arrowSize={200}
          arrowOffset={34}
          arrowScaleLeft={1}
          arrowScaleRight={1}
          arrowShiftLeft={{ x: -70, y: -28 }}
          arrowShiftRight={{ x: 70, y: -28 }}
        />
      </div>

      {/* ===== กริด ===== */}
      <div ref={gridRef} className="mx-auto max-w-[1320px] px-6">
        <div className="mt-4 mb-6 flex items-center justify-between">
          <h2 className="text-xl font-semibold tracking-wide">
            รายการ{tab === "comic" ? "การ์ตูน" : "นิยาย"} — หน้า {page}/{TOTAL_PAGES}
          </h2>
        </div>

        <motion.div
          key={`${tab}-${page}`}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="grid grid-cols-2 gap-8"
        >
          {items.map((it) => (
            <DetailCard key={it.id} it={it} tab={tab} />
          ))}
        </motion.div>
      </div>

      {/* ===== ตะเกียงล่าง ===== */}
      <div className="relative mx-auto max-w-[1320px] h-[400px] mt-10 mb-8 overflow-visible">
        <CenterLanterns
          tab={tab}
          onSelect={(t) => {
            setTab(t);
            warpNext.current = true;
            setPage(1);
            forceWarpSoon();
          }}
          page={page}
          totalPages={TOTAL_PAGES}
          onPrev={goPrevBottom}
          onNext={goNextBottom}
          onJump={jumpBottom}
          showSidePages
          sideCount={2}
          anchor="center"
          x={50}
          y={40}
          unit="%"
          scale={0.72}
          z={10}
          pointer="auto"
          containerClassName="mx-auto"
          ringSize={380}
          ringRotate={0}
          ringOpacity={1}
          ringGlow={0}
          ringOffsetX={0}
          ringOffsetY={0}
          arrowSize={200}
          arrowOffset={34}
          arrowScaleLeft={1}
          arrowScaleRight={1}
          arrowShiftLeft={{ x: -70, y: -24 }}
          arrowShiftRight={{ x: 70, y: -24 }}
        />
      </div>
    </section>
  );
}

/* =========================
   ⭐ Star (ขาวเรียบ ไม่มีแสง)
========================= */
function Star({ rating, uid }: { rating: number; uid: string }) {
  const full = Math.floor(rating);
  const half = rating - full >= 0.5;
  const arr = Array.from({ length: 5 }).map((_, i) => {
    if (i < full) return "full";
    if (i === full && half) return "half";
    return "empty";
  });
  return (
    <span className="inline-flex items-center text-[#e5e5e5]">
      {arr.map((t, i) => (
        <svg key={i} width="14" height="14" viewBox="0 0 24 24" className="mr-[2px]">
          {t === "full" && (
            <path
              d="M12 2l3.09 6.36 7.01 1.02-5.05 4.92 1.19 6.94L12 18.77 5.76 21.24l1.19-6.94L1.9 9.38l7.01-1.02L12 2z"
              fill="#e5e5e5"
            />
          )}
          {t === "half" && (
            <>
              <defs>
                <linearGradient id={`g-${uid}-${i}`} x1="0" x2="1">
                  <stop offset="50%" stopColor="#e5e5e5" />
                  <stop offset="50%" stopColor="transparent" />
                </linearGradient>
              </defs>
              <path
                d="M12 2l3.09 6.36 7.01 1.02-5.05 4.92 1.19 6.94L12 18.77 5.76 21.24l1.19-6.94L1.9 9.38l7.01-1.02L12 2z"
                fill={`url(#g-${uid}-${i})`}
                stroke="#e5e5e5"
              />
            </>
          )}
          {t === "empty" && (
            <path
              d="M12 2l3.09 6.36 7.01 1.02-5.05 4.92 1.19 6.94L12 18.77 5.76 21.24l1.19-6.94L1.9 9.38l7.01-1.02L12 2z"
              fill="none"
              stroke="#e5e5e5"
            />
          )}
        </svg>
      ))}
      <span className="ml-1 text-[#cfcfcf] text-[12px]">{rating.toFixed(1)}</span>
    </span>
  );
}

/* =========================
   🔖 บุ๊คมาร์กแบบเรียบ
========================= */
function LanternBookmarkButton({
  active,
  onToggle,
}: {
  active: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      aria-label="บุ๊คมาร์ก"
      className={`
        absolute top-2 right-2 z-20 w-8 h-8 grid place-items-center
        rounded-full border border-white/20 bg-black/30 backdrop-blur-sm
        hover:bg-white/10 transition-all duration-150
        ${active ? "text-white" : "text-white/80"}
      `}
    >
      {active ? (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <path d="M6 2a2 2 0 0 0-2 2v18l8-5 8 5V4a2 2 0 0 0-2-2H6z" />
        </svg>
      ) : (
        <svg
          width="18"
          height="18"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.6"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
        </svg>
      )}
    </button>
  );
}

/* =========================
   ➕ ปุ่มติดตามแบบไอคอนคน + บวก
========================= */
function FollowButton({
  following,
  onToggle,
}: {
  following: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      aria-label={following ? "กำลังติดตาม" : "ติดตาม"}
      className={`
        ml-2 inline-grid place-items-center
        h-[20px] w-[20px] rounded-full
        transition-colors duration-150
        ${following
          ? "bg-white text-black border border-white/0"
          : "bg-transparent text-white/85 border border-white/25 hover:bg-white/10"}
      `}
    >
      {following ? (
        // วงกลมขาว + ติ๊กถูกดำ
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M20 6 9 17l-5-5" />
        </svg>
      ) : (
        // ไอคอน “คน +”
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M16 21v-1a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v1" />
          <circle cx="10" cy="7" r="3" />
          <path d="M19 8v6" />
          <path d="M22 11h-6" />
        </svg>
      )}
    </button>
  );
}

/* =========================
   🏷️ ป้ายหมวด (พอดีข้อความ พื้นขาว/ตัวดำ)
========================= */
function CategoryBadge({ tab }: { tab: Tab }) {
  const label = tab === "comic" ? "การ์ตูน" : "นิยาย";
  return (
    <span
      className="
        inline-flex w-fit self-start items-center
        px-2.5 py-[2px] rounded-md
        bg-white text-black
        text-[12px] font-medium shadow-sm mt-2
      "
    >
      {label}
    </span>
  );
}

/* =========================
   📘 การ์ดหลัก (สีเรียบไม่เรืองแสง)
========================= */
function DetailCard({ it, tab }: { it: Item; tab: Tab }) {
  const last = Math.max(1, it.chapters);
  const recents = [last, Math.max(1, last - 1), Math.max(1, last - 2)];
  const agoList = ["1 ชั่วโมงที่แล้ว", "7 วันก่อน", "7 วันก่อน"];

  const [bookmarked, setBookmarked] = useState(false);
  const [following, setFollowing] = useState(false);

  return (
    <article
      className="
        group relative w-full rounded-2xl border border-white/10
        bg-white/[0.03] hover:bg-white/[0.05] transition-colors duration-150
      "
    >
      <LanternBookmarkButton
        active={bookmarked}
        onToggle={() => setBookmarked((v) => !v)}
      />

      <div className="flex items-stretch gap-3.5 p-3.5">
        {/* รูปปก — ขยายให้เต็มกรอบ */}
        <div className="relative shrink-0 w-[156px] h-[220px] overflow-hidden rounded-xl border border-white/15">
          <img
            src={it.cover_url}
            alt={it.title}
            className="block w-full h-full object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/40 pointer-events-none" />
        </div>

        <div className="flex-1 min-w-0 flex flex-col justify-between py-[6px] pt-2">
          <div className="flex flex-col gap-[6px] pr-12">
            {/* ชื่อเรื่อง */}
            <h3 className="text-[18px] font-semibold leading-tight line-clamp-2">
              {it.title}
            </h3>

            {/* ป้ายหมวด */}
            <CategoryBadge tab={tab} />

            {/* ผู้แต่ง + ปุ่มติดตาม */}
            <div className="mt-[10px] text-[15px] text-white/85 leading-snug flex items-center ">
              <span className="mr-1">ผู้แต่ง:</span>
              <span className="text-white font-medium">{it.author}</span>
              <FollowButton
                following={following}
                onToggle={() => setFollowing((v) => !v)}
              />
            </div>

            {/* ดาว/ตอน/วิว */}
            <div className="flex flex-wrap items-center gap-x-4 gap-y-[5px] text-[16px] leading-none mt-[2px]">
              <span className="flex items-center text-[#e5e5e5]">
                <Star rating={it.rating} uid={String(it.id)} />
              </span>
              <div className="h-[13px] w-px bg-white/15" />
              <span className="text-white/80">ตอน {it.chapters}</span>
              <div className="h-[13px] w-px bg-white/15" />
              <span className="text-white/80">{it.views} วิว</span>
            </div>
          </div>

          {/* ตอนล่าสุด */}
          <div className="flex flex-col gap-[6px] mt-0.5">
            <div className="h-px bg-white/10" />
            <ul className="space-y-[15px]">
              {recents.map((ch, idx) => (
                <li
                  key={ch}
                  className="flex items-center justify-between leading-tight"
                >
                  <div className="flex items-center gap-2 text-[14px]">
                    <span>
                      ตอนที่ <span className="font-semibold">{ch}</span>
                    </span>
                    <span className="text-white/80" aria-hidden>
                      🪙
                    </span>
                  </div>
                  <span className="text-[13px] text-white/65">
                    {agoList[idx] || it.updated}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </article>
  );
}
