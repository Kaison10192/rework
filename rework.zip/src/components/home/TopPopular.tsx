// src/components/home/TopPopular.tsx
"use client";

import { useMemo, useRef, useState, useEffect, CSSProperties } from "react";

/* ============ ปรับตำแหน่งง่าย ๆ ตรงนี้ ============ */
const UI_POS = {
  heading: { top: -70, left: 630 }, // ข้อความ "10 อันดับยอดนิยม"
  tabs:    { top: -70, left: 930 }, // ปุ่มสลับ การ์ตูน/นิยาย
  viewAll: { top: -45, left: -10 }, // << ดูทั้งหมด (มุมบนซ้าย)
};
/* ==================================================== */

/* ---------------- Mock data ---------------- */
type Item = { id: string; title: string; cover: string };

const COVERS = [
  "https://images.unsplash.com/photo-1549187774-b4e9b0445b41?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1526318472351-c75fcf070305?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1519677100203-a0e668c92439?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1520975916090-3105956dac38?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1482192596544-9eb780fc7f66?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1500534623283-312aade485b7?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?q=80&w=1200&auto=format&fit=crop",
];

function makeItems(kind: "comic" | "novel"): Item[] {
  return Array.from({ length: 10 }).map((_, i) => ({
    id: `${kind}-${i + 1}`,
    title: kind === "comic" ? `การ์ตูนตัวอย่าง #${i + 1}` : `นิยายตัวอย่าง #${i + 1}`,
    cover: COVERS[i % COVERS.length],
  }));
}

/* ---------------- ปุ่มมังงะ/นิยาย (ดีไซน์เหลี่ยม) ---------------- */
function MangaNovelButtons({
  value,
  onChange,
  className = "",
  style,
}: {
  value: "comic" | "novel";
  onChange: (v: "comic" | "novel") => void;
  className?: string;
  style?: CSSProperties;
}) {
  const isComic = value === "comic";
  return (
    <div className={`glitch-tabs ${className ?? ""}`} style={style}>
      <div className="container">
        <div className="radio-wrapper">
          <input
            type="radio"
            name="mn-tabs"
            className="input"
            checked={isComic}
            onChange={() => onChange("comic")}
            aria-label="เลือกการ์ตูน"
          />
          <div className="btn">การ์ตูน</div>
        </div>

        <div className="radio-wrapper">
          <input
            type="radio"
            name="mn-tabs"
            className="input"
            checked={!isComic}
            onChange={() => onChange("novel")}
            aria-label="เลือกนิยาย"
          />
          <div className="btn">นิยาย</div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- View All Button (ปุ่มเหลี่ยมมุมบนซ้าย) ---------------- */
function ViewAllButton({
  href = "#",
  className = "",
  style,
}: {
  href?: string;
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <>
      <a href={href} className={`viewall-btn ${className}`} >
        &laquo; ดูทั้งหมด
      </a>

      {/* สไตล์ปุ่มเหลี่ยม เรียบๆ ไม่มีเอฟเฟกต์ */}
      <style jsx>{`
        .viewall-btn {
          --clip: polygon(11% 0,95% 0,100% 25%,90% 90%,95% 90%,85% 90%,85% 100%,7% 100%,0 80%);
          --border: 4px;

          position: absolute;
          display: inline-block;
          padding: 6px 14px;
          font-size: 14px;
          font-weight: 700;
          color: #e5e7eb; /* text-gray-200 */
          text-decoration: none;
          line-height: 1;
          transform: translateZ(0);
        }
        .viewall-btn::before,
        .viewall-btn::after {
          content: "";
          position: absolute;
          inset: 0;
          clip-path: var(--clip);
          z-index: -1;
          transition: background 0.2s ease, transform 0.2s ease;
        }
        .viewall-btn::before {
          background: #9ca3af; /* ขอบเทา */
          transform: translate(var(--border), 0);
        }
        .viewall-btn::after {
          background: #111827; /* พื้นดำ */
        }
        .viewall-btn:hover {
          color: #ffffff;
        }
        .viewall-btn:hover::after {
          background: #1f2937; /* hover เข้มขึ้นนิดนึง */
        }
        .viewall-btn:active::after {
          background: #000000; /* คลิกให้ดำสนิท */
        }
      `}</style>
    </>
  );
}

/* ---------------- Page Grid ---------------- */
const PAGE_SIZE = 5;
const SLIDE_MS = 400;

function PageGrid({
  items,
  baseIndex,
  tab,
}: {
  items: Item[];
  baseIndex: number;
  tab: "comic" | "novel";
}) {
  return (
    <div className="grid grid-cols-5 gap-6 w-full overflow-visible pl-[18px] pr-[18px] md:pl-[20px] md:pr-[20px]">
      {items.map((it, idx) => {
        const rank = baseIndex + idx + 1;
        return (
          <article key={it.id} className="relative select-none overflow-visible pb-10 md:pb-12">
            <div className="relative rounded-xl overflow-hidden w-full h-[360px] md:h-[320px] bg-white/5">
              <img
                src={it.cover}
                alt={it.title}
                width={600}
                height={800}
                className="w-full h-full object-cover"
              />
              <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[60px] bg-gradient-to-t from-black/60 to-transparent" />
            </div>

            {/* ลำดับ */}
            <div
              className="pointer-events-none absolute left-2 md:left-[-15px] bottom-[-10px] md:bottom-[90px] z-20 font-extrabold"
              style={{
                fontSize: "72px",
                lineHeight: 1,
                color: "#000",
                WebkitTextStroke: "4px #fff",
                textShadow: "0 2px 6px rgba(0,0,0,.25)",
              }}
            >
              {rank}
            </div>

            <h3 className="mt-6 text-[15px] md:text-[16px] font-medium line-clamp-2">
              {it.title}
            </h3>
            <div className="mt-1 text-[13px] text-white/60">
              {tab === "comic" ? "โรแมนซ์แฟนตาซี" : "ดราม่า"}
            </div>
          </article>
        );
      })}
    </div>
  );
}

/* ---------------- Main ---------------- */
export default function TopPopular() {
  const [tab, setTab] = useState<"comic" | "novel">("comic");
  const [page, setPage] = useState(0);
  const [animating, setAnimating] = useState(false);
  const [dir, setDir] = useState<1 | -1>(1);
  const [offsetPx, setOffsetPx] = useState(0);
  const [targetPage, setTargetPage] = useState<number | null>(null);

  const viewportRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const fixedWidth = useRef<number | null>(null);

  const data = useMemo(
    () => (tab === "comic" ? makeItems("comic") : makeItems("novel")),
    [tab]
  );

  const totalPages = Math.ceil(data.length / PAGE_SIZE);
  const start = page * PAGE_SIZE;
  const currItems = data.slice(start, start + PAGE_SIZE);
  const prevItems = data.slice(
    Math.max(0, page - 1) * PAGE_SIZE,
    Math.max(0, page - 1) * PAGE_SIZE + PAGE_SIZE
  );
  const nextItems = data.slice(
    Math.min(totalPages - 1, page + 1) * PAGE_SIZE,
    Math.min(totalPages - 1, page + 1) * PAGE_SIZE + PAGE_SIZE
  );

  const doSlide = (toPage: number) => {
    if (animating || toPage === page) return;
    const forward = toPage > page;
    const vp = viewportRef.current?.clientWidth ?? 0;
    fixedWidth.current = vp;
    setDir(forward ? 1 : -1);
    setTargetPage(toPage);
    setAnimating(true);
    setOffsetPx(forward ? 0 : vp);
    requestAnimationFrame(() => setOffsetPx(forward ? vp : 0));
  };

  useEffect(() => {
    if (!animating) return;
    const el = trackRef.current;
    if (!el) return;
    const onEnd = () => {
      if (targetPage !== null) setPage(targetPage);
      setAnimating(false);
      setTargetPage(null);
      setOffsetPx(0);
      fixedWidth.current = null;
    };
    el.addEventListener("transitionend", onEnd, { once: true });
    return () => el.removeEventListener("transitionend", onEnd);
  }, [animating, targetPage]);

  const goPrev = () => page > 0 && doSlide(page - 1);
  const goNext = () => page < totalPages - 1 && doSlide(page + 1);

  return (
    <section className="relative mx-auto max-w-[1320px] px-6 pt-6 md:pt-9">
      {/* กรอบมุม 4 ด้าน */}
      <img src="/มุมซ้ายบน.png" alt="" className="absolute top-[0px] left-[-70px] w-[180px] md:w-[800px] z-30 pointer-events-none" />
      <img src="/มุมขวาบน.png" alt="" className="absolute top-[-10px] right-[-67px] w-[180px] md:w-[260px] z-30 pointer-events-none" />
      <img src="/มุมซ้ายล่าง.png" alt="" className="absolute bottom-[-59px] left-[-67px] w-[180px] md:w-[220px] z-30 pointer-events-none" />
      <img src="/มุมขวาล่าง.png" alt="" className="absolute bottom-[-50px] right-[-100px] w-[180px] md:w-[600px] z-30 pointer-events-none" />

      {/* เนื้อหา */}
      <div className="relative z-10">
        <div className="mb-4 md:mb-25 relative">
          
          {/* 🔹 ปุ่ม << ดูทั้งหมด (ข้อความธรรมดา) */}
          <a
            href="/popular"
            style={{
              position: "absolute",
              top: UI_POS.viewAll.top,
              left: UI_POS.viewAll.left,
              color: "#ffffff",
              fontSize: "18px", // ✅ ปรับขนาดตัวอักษร
              fontWeight: 600,
              textDecoration: "none",
              cursor: "pointer",
            }}
            onMouseEnter={(e) => (e.currentTarget.style.textDecoration = "underline")}
            onMouseLeave={(e) => (e.currentTarget.style.textDecoration = "none")}
          >
            &laquo; ดูทั้งหมด
          </a>

          {/* หัวข้อ */}
          <h2
            className="absolute text-xl md:text-4xl font-semibold"
            style={{ left: UI_POS.heading.left, top: UI_POS.heading.top }}
          >
            10 อันดับยอดนิยม
          </h2>

          {/* ปุ่มมังงะ/นิยาย */}
          <MangaNovelButtons
            value={tab}
            onChange={(v) => {
              setTab(v);
              setPage(0);
            }}
            className="absolute"
            style={{ top: UI_POS.tabs.top, left: UI_POS.tabs.left }}
          />
        </div>

        {/* การ์ด + สไลด์ */}
        <div className="relative">
          <div ref={viewportRef} className="overflow-hidden">
            {!animating && <PageGrid items={currItems} baseIndex={start} tab={tab} />}
            {animating && (
              <div
                ref={trackRef}
                className="flex will-change-transform"
                style={{
                  width: `calc(${(fixedWidth.current ?? 0)}px * 2)`,
                  transform: `translate3d(-${offsetPx}px,0,0)`,
                  transition: `transform ${SLIDE_MS}ms ease`,
                }}
              >
                {dir === 1 ? (
                  <>
                    <div style={{ width: fixedWidth.current ?? "100%" }} className="flex-none">
                      <PageGrid items={currItems} baseIndex={start} tab={tab} />
                    </div>
                    <div style={{ width: fixedWidth.current ?? "100%" }} className="flex-none">
                      <PageGrid items={nextItems} baseIndex={(page + 1) * PAGE_SIZE} tab={tab} />
                    </div>
                  </>
                ) : (
                  <>
                    <div style={{ width: fixedWidth.current ?? "100%" }} className="flex-none">
                      <PageGrid items={prevItems} baseIndex={(page - 1) * PAGE_SIZE} tab={tab} />
                    </div>
                    <div style={{ width: fixedWidth.current ?? "100%" }} className="flex-none">
                      <PageGrid items={currItems} baseIndex={start} tab={tab} />
                    </div>
                  </>
                )}
              </div>
            )}
          </div>

          {/* ปุ่มลูกศร */}
          {page > 0 && !animating && (
            <button
              onClick={goPrev}
              className="absolute z-40"
              style={{ top: "80px", left: "-160px", width: "200px", height: "200px", background: "transparent", border: "none", padding: 0, cursor: "pointer" }}
              aria-label="ก่อนหน้า"
            >
              <img src="/arrow.png" alt="ก่อนหน้า" className="w-full h-full object-contain rotate-180" style={{ filter: "brightness(0) invert(1)" }} />
            </button>
          )}
          {page < totalPages - 1 && !animating && (
            <button
              onClick={goNext}
              className="absolute z-40"
              style={{ top: "80px", right: "-160px", width: "200px", height: "200px", background: "transparent", border: "none", padding: 0, cursor: "pointer" }}
              aria-label="ถัดไป"
            >
              <img src="/arrow.png" alt="ถัดไป" className="w-full h-full object-contain" style={{ filter: "brightness(0) invert(1)" }} />
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
