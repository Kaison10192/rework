"use client";
import LanternIcon from "./LanternIcon";
import { useState } from "react";

export default function Navbar() {
  const [active, setActive] = useState("home");

  const menu = [
    { key: "home", label: "หน้าแรก" },
    { key: "manga", label: "การ์ตูน" },
    { key: "novel", label: "นิยาย" },
    { key: "about", label: "เกี่ยวกับเรา" },
  ];

  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-[rgba(235,203,139,0.15)]">
      <nav className="max-w-6xl mx-auto flex items-center justify-between px-6 py-3">
        {/* โลโก้ */}
        <div className="flex items-center gap-2">
          <LanternIcon className="w-6 h-6 text-lantern lantern-pulse" />
          <span className="font-[var(--font-heading)] text-lantern text-xl glow-text tracking-wide">
            TAKIANG
          </span>
        </div>

        {/* เมนู */}
        <ul className="flex items-center gap-6">
          {menu.map((m) => (
            <li
              key={m.key}
              onClick={() => setActive(m.key)}
              className={`cursor-pointer transition ${
                active === m.key
                  ? "text-flame"
                  : "text-[color:var(--color-text-dim)] hover:text-lantern"
              }`}
            >
              {m.label}
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
